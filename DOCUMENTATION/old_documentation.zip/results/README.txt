WAZNE ABY OGARNAC CO SIE DZIEJE W TYCH FOLDERACH - CZYTAJ I NIE MARUDZ KAMIL!

1) Analityczny przechowuje wygenerowane dane dla obu metod i konkretnej ilosci min
(zakladamy ze beda to kolejno dane: plansza 7x7, 5 min; plansza 10x10, 10 min; plansza 20x20, 20 min; Aby sie nie pojebało)

2) Kazda siec w folderze neural netowork ma wlasny folder, kazdy z tych folderow przechowuje wygnerowane modele, rezultaty z trenowania i rezulataty z testowania - one sa rowniez rozroznianie na podstawie metody, ilosic min oraz WIELKOSCI DANYCH TRENINGOWYCH (np. 1000_iterations, czyli dla danych wygenerowanych z 1000 iteracji, nie ilosci danych podczas testowania), na ktorych zostaly wytrenowane te modele. Folder rezultatow z testow zawiera rowniez na koncu podzial na pelne rozgrywki i kolejne ruchy (1, 3 oraz 5). Dodatkowo dla metody 5x5 zawarty jest tez folder przechowujacy wygenerowane dla danego modelu drzewo decyzyjne (tylko dla 5x5!).

Miejcie na uwadze ze u nas dziala to w ten sposob ze rozmiar planszy przy testowaniu i trenowaniu musi byc ten sam, 
wiec jak chcecie testowac mniejsze lub wieksze plansze to trzeba jeszcze raz trenowac model :/ (zamiast np. trenowac dla 20x20 i testowac dla pozostalych)



